import { Grid2x2, Plus, CircleUserRound } from 'lucide-react';
import { SideDrawer } from './SideDrawer';

export const BottomIsland = ({
    onCreateExpense,
    userEmail,
    onLogout,
    isHamburgerOpen,
    onHamburgerOpenChange,
    compact = false,
    theme = 'dark',
    onToggleTheme,
    onOpenExpenses,
    onOpenFriends
}) => {
    return (
        <>
            <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-60 w-full px-4 sm:px-6 pointer-events-none">
                <div
                    className={`mx-auto pointer-events-auto max-w-100 rounded-full border px-3 py-3 glass-shell transition-all duration-300 ${compact ? 'scale-95 opacity-85' : 'scale-100 opacity-100'}`}
                    style={{ background: 'var(--surface)', borderColor: 'var(--surface-border)' }}
                >
                    <div className="grid grid-cols-[56px_1fr_56px] items-center gap-2">
                        <button
                            type="button"
                            onClick={() => onHamburgerOpenChange(true)}
                            className="h-12 w-12 rounded-full border border-white/10 bg-white/5 flex items-center justify-center text-primary hover:bg-white/10 transition-all"
                            aria-label="Abrir menú"
                        >
                            <Grid2x2 size={18} />
                        </button>

                        <button
                            onClick={onCreateExpense}
                            className="relative h-14 w-14 mx-auto -translate-y-0 rounded-full flex items-center justify-center text-white font-extrabold transition-all active:scale-95 shadow-2xl"
                            style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-strong))', boxShadow: '0 18px 40px -14px rgba(139, 92, 246, 0.65)' }}
                            aria-label="Añadir gasto"
                        >
                            <Plus size={22} />
                        </button>

                        <button
                            type="button"
                            onClick={() => onHamburgerOpenChange(true)}
                            className="h-12 w-12 rounded-full border border-white/10 bg-white/5 flex items-center justify-center overflow-hidden hover:bg-white/10 transition-all"
                            aria-label="Abrir perfil"
                        >
                            <CircleUserRound size={20} className="text-primary" />
                        </button>
                    </div>
                </div>
            </div>

            <SideDrawer
                isOpen={isHamburgerOpen}
                onOpenChange={onHamburgerOpenChange}
                theme={theme}
                onToggleTheme={onToggleTheme}
                onLogout={onLogout}
                onOpenExpenses={onOpenExpenses}
                onOpenFriends={onOpenFriends}
                onCreateExpense={onCreateExpense}
                userEmail={userEmail}
            />
        </>
    );
};
