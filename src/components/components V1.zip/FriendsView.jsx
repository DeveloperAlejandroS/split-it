import { useMemo, useState } from 'react';
import { CheckCircle2, Loader2, RefreshCw, Search, UserPlus, Users } from 'lucide-react';
import { GlassCard } from './GlassCard';

const API_URL = 'https://expense-tracker-api-0762.onrender.com';

const getFriendUser = (friend) => friend?.user || friend?.friend || friend?.profile || friend || {};

const getDisplayName = (user) => {
    const parts = [user?.first_name, user?.middle_name, user?.last_name, user?.second_last_name]
        .map((part) => (typeof part === 'string' ? part.trim() : ''))
        .filter(Boolean);

    if (parts.length > 0) return parts.join(' ');
    if (user?.username) return user.username;
    if (user?.email) return user.email;
    return 'Usuario sin nombre';
};

const getFriendStatus = (friend) => friend?.status || friend?.friendship_status || 'accepted';

const getFriendKey = (friend, index) => friend?.id ?? friend?.user_id ?? friend?.friend_id ?? index;

const getRequestUser = (request) => request?.requester || request?.from_user || request?.user || request;

const getRequestId = (request) => request?.request_id ?? request?.friendship_id ?? request?.relation_id ?? request?.id;

const SHEET_MARGIN_BOTTOM = 'calc(env(safe-area-inset-bottom, 0px) + 85px)';

const FriendRow = ({ friend }) => {
    const user = getFriendUser(friend);
    const status = getFriendStatus(friend);
    const subtitleParts = [user?.username, user?.email, user?.phone].filter(Boolean);

    return (
        <div className="rounded-3xl border border-white/10 bg-white/5 p-4 flex items-center justify-between gap-4">
            <div className="min-w-0">
                <p className="text-sm font-semibold text-white truncate">{getDisplayName(user)}</p>
                <p className="text-xs text-white/45 truncate">{subtitleParts.join(' · ')}</p>
            </div>
            <span className="shrink-0 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] text-emerald-300">
                {status}
            </span>
        </div>
    );
};

export const FriendsView = ({ friends = [], pendingRequests = [], token, onRefresh, isLoading, theme = 'dark' }) => {
    const [isAddFriendOpen, setIsAddFriendOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [searchLoading, setSearchLoading] = useState(false);
    const [requestingUserId, setRequestingUserId] = useState(null);
    const [acceptingRequestId, setAcceptingRequestId] = useState(null);
    const [localMessage, setLocalMessage] = useState('');

    const hasFriends = useMemo(() => friends.length > 0, [friends]);
    const hasPendingRequests = useMemo(() => pendingRequests.length > 0, [pendingRequests]);

    const openAddFriend = () => {
        setIsAddFriendOpen(true);
        setSearchTerm('');
        setSearchResults([]);
        setLocalMessage('');
    };

    const searchUsers = async (event) => {
        event.preventDefault();
        const query = searchTerm.trim();

        if (!query || !token) return;

        setSearchLoading(true);
        setLocalMessage('');

        try {
            const response = await fetch(`${API_URL}/users/search?q=${encodeURIComponent(query)}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    Accept: 'application/json'
                }
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'No se pudo buscar usuarios');
            }

            const users = Array.isArray(data?.users) ? data.users : Array.isArray(data) ? data : [];
            setSearchResults(users.filter((user) => Number(user?.id) > 0));
        } catch (error) {
            setLocalMessage(error.message);
        } finally {
            setSearchLoading(false);
        }
    };

    const requestFriend = async (userId) => {
        if (!token || !userId) return;

        setRequestingUserId(userId);
        setLocalMessage('');

        try {
            const response = await fetch(`${API_URL}/friends/request`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                    Accept: 'application/json'
                },
                body: JSON.stringify({ user_id: Number(userId) })
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'No se pudo enviar la solicitud');
            }

            setLocalMessage(data.message || 'Solicitud enviada');
            await onRefresh?.();
        } catch (error) {
            setLocalMessage(error.message);
        } finally {
            setRequestingUserId(null);
        }
    };

    const acceptRequest = async (requestId) => {
        if (!token || !requestId) return;

        setAcceptingRequestId(requestId);
        setLocalMessage('');

        try {
            const response = await fetch(`${API_URL}/friends/${requestId}/accept`, {
                method: 'PATCH',
                headers: {
                    Authorization: `Bearer ${token}`,
                    Accept: 'application/json'
                }
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'No se pudo aceptar la solicitud');
            }

            setLocalMessage(data.message || 'Solicitud aceptada');
            await onRefresh?.();
        } catch (error) {
            setLocalMessage(error.message);
        } finally {
            setAcceptingRequestId(null);
        }
    };

    return (
        <section className="space-y-6">
            <div className="flex items-center justify-between gap-3 px-2">
                <div>
                    <h3 className="text-lg font-bold text-primary">Amigos</h3>
                    <p className="text-xs text-secondary">Lista de amigos aceptados del usuario logueado</p>
                </div>

                <div className={`flex items-center gap-2 ${hasFriends ? 'opacity-70' : 'opacity-100'}`}>
                    <button
                        type="button"
                        onClick={onRefresh}
                        disabled={isLoading}
                        className="p-2 rounded-full border transition-all duration-500 disabled:opacity-50"
                        style={{ background: 'var(--surface-soft)', borderColor: 'var(--surface-border)', color: 'var(--text-secondary)' }}
                    >
                        <RefreshCw size={18} />
                    </button>

                    <button
                        type="button"
                        onClick={openAddFriend}
                        className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-all ${
                            hasFriends
                                ? 'bg-white/5 border border-white/10 text-white/60 hover:text-white hover:bg-white/10'
                                : 'bg-violet-500 text-white shadow-lg shadow-violet-500/20 hover:bg-violet-400'
                        }`}
                    >
                        <UserPlus size={16} />
                        Añadir amigo
                    </button>
                </div>
            </div>

            {hasFriends ? (
                <div className="space-y-3">
                    {friends.map((friend, index) => (
                        <FriendRow key={getFriendKey(friend, index)} friend={friend} />
                    ))}
                </div>
            ) : (
                <div className="rounded-3xl border border-dashed border-white/10 bg-white/5 px-6 py-14 text-center space-y-4">
                    <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/35">
                        <Users size={24} />
                    </div>
                    <div>
                        <h4 className="text-base font-semibold text-white/90">Todavía no tienes amigos</h4>
                        <p className="text-sm text-white/35">Puedes buscarlos por email, usuario o nombre y enviarles una solicitud.</p>
                    </div>
                    <button
                        type="button"
                        onClick={openAddFriend}
                        className="inline-flex items-center gap-2 rounded-full bg-violet-500 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-violet-500/20 transition-all hover:bg-violet-400"
                    >
                        <UserPlus size={16} />
                        Añadir amigo
                    </button>
                </div>
            )}

            <section className="space-y-3">
                <div className="flex items-center justify-between px-2">
                    <h4 className="text-sm font-bold uppercase tracking-[0.2em] text-white/50">Solicitudes pendientes</h4>
                    {isLoading && <Loader2 size={14} className="animate-spin text-white/40" />}
                </div>

                {hasPendingRequests ? (
                    <div className="space-y-3">
                        {pendingRequests.map((request, index) => {
                            const user = getRequestUser(request);
                            const requestId = getRequestId(request);
                            const disabled = !requestId || acceptingRequestId === requestId;

                            return (
                                <GlassCard key={requestId ?? index} theme={theme} className="p-4 flex items-center justify-between gap-4">
                                    <div className="min-w-0">
                                        <p className="text-sm font-semibold text-primary truncate">{getDisplayName(user)}</p>
                                        <p className="text-xs text-secondary truncate">{[user?.username, user?.email, user?.phone].filter(Boolean).join(' · ')}</p>
                                    </div>

                                    <button
                                        type="button"
                                        onClick={() => acceptRequest(requestId)}
                                        disabled={disabled}
                                        className={`shrink-0 inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold transition-all ${
                                            disabled
                                                ? 'bg-white/5 text-secondary border border-white/10 cursor-not-allowed'
                                                : 'bg-emerald-500 text-white hover:bg-emerald-400'
                                        }`}
                                    >
                                        {acceptingRequestId === requestId ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
                                        {requestId ? 'Aceptar' : 'Sin ID solicitud'}
                                    </button>
                                </GlassCard>
                            );
                        })}
                    </div>
                ) : (
                    <GlassCard theme={theme} className="rounded-2xl border-dashed px-4 py-6 text-center text-sm text-secondary">
                        No tienes solicitudes pendientes.
                    </GlassCard>
                )}
            </section>

            {isAddFriendOpen && (
                <div className="fixed inset-0 z-90 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 sm:p-6">
                    <div className="w-full max-w-xl rounded-4xl border border-white/10 bg-slate-950/95 shadow-2xl shadow-black/40 overflow-hidden">
                        <div className="border-b border-white/10 px-5 py-4">
                            <h4 className="text-lg font-bold text-white">Añadir amigo</h4>
                            <p className="text-xs text-white/40">Busca por usuario, nombre, email o teléfono.</p>
                        </div>

                        <form onSubmit={searchUsers} className="space-y-4 px-5 py-5">
                            <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/35" size={18} />
                                <input
                                    value={searchTerm}
                                    onChange={(event) => setSearchTerm(event.target.value)}
                                    placeholder="Buscar usuario"
                                    className="w-full rounded-2xl border border-white/10 bg-white/5 py-3 pl-11 pr-4 text-sm text-white outline-none transition-all placeholder:text-white/25 focus:border-violet-400/50"
                                />
                            </div>

                            {localMessage && (
                                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/70">
                                    {localMessage}
                                </div>
                            )}

                            <button
                                type="submit"
                                disabled={searchLoading}
                                className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-violet-500 px-4 py-3 text-sm font-semibold text-white transition-all hover:bg-violet-400 disabled:opacity-60"
                            >
                                {searchLoading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
                                Buscar
                            </button>
                        </form>

                        <div className="max-h-90 space-y-3 overflow-y-auto px-5 pb-5">
                            {searchResults.length === 0 ? (
                                <p className="rounded-2xl border border-white/10 bg-white/5 px-4 py-6 text-center text-sm text-white/35">
                                    No hay resultados para mostrar.
                                </p>
                            ) : (
                                searchResults.map((user) => {
                                    const alreadyLinked = user?.friendship_status && user.friendship_status !== 'none';
                                    const requestDisabled = alreadyLinked || requestingUserId === user.id;

                                    return (
                                        <div key={user.id} className="rounded-3xl border border-white/10 bg-white/5 p-4 flex items-start justify-between gap-4">
                                            <div className="min-w-0">
                                                <p className="text-sm font-semibold text-white truncate">{getDisplayName(user)}</p>
                                                <p className="text-xs text-white/40 truncate">{[user?.username, user?.email, user?.phone].filter(Boolean).join(' · ')}</p>
                                                {user?.friendship_status && (
                                                    <p className="mt-2 text-[10px] uppercase tracking-[0.24em] text-white/35">
                                                        Estado: {user.friendship_status}
                                                    </p>
                                                )}
                                            </div>

                                            <button
                                                type="button"
                                                onClick={() => requestFriend(user.id)}
                                                disabled={requestDisabled}
                                                className={`shrink-0 inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold transition-all ${
                                                    requestDisabled
                                                        ? 'bg-white/5 text-white/30 border border-white/10 cursor-not-allowed'
                                                        : 'bg-emerald-500 text-white hover:bg-emerald-400'
                                                }`}
                                            >
                                                {requestingUserId === user.id ? <Loader2 size={14} className="animate-spin" /> : <UserPlus size={14} />}
                                                {alreadyLinked ? 'Ya vinculado' : 'Agregar'}
                                            </button>
                                        </div>
                                    );
                                })
                            )}
                        </div>

                        <div className="border-t border-white/10 px-5 py-4 flex justify-end">
                            <button
                                type="button"
                                onClick={() => setIsAddFriendOpen(false)}
                                className="rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-white/70 hover:text-white hover:bg-white/10 transition-all"
                            >
                                Cerrar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </section>
    );
};