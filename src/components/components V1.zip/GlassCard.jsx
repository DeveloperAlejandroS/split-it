export const GlassCard = ({
    children,
    className = '',
    theme = 'dark'
}) => {
    const themeClass = theme === 'light'
        ? 'bg-white/40 border border-white/50 backdrop-blur-[20px] text-slate-900'
        : 'bg-slate-900/60 border border-white/10 backdrop-blur-lg text-slate-50';

    return (
        <div className={`glass-shell rounded-3xl ${themeClass} ${className}`}>
            {children}
        </div>
    );
};