import { Menu, X, LogOut } from 'lucide-react';

export const HamburgerMenu = ({
    userEmail,
    onLogout,
    isOpen,
    onOpenChange,
    compact = false,
    panelPosition = 'bottom'
}) => {

    return (
        <>
            <button
                onClick={() => onOpenChange(!isOpen)}
                className={compact
                    ? 'h-12 w-12 flex items-center justify-center bg-white/5 hover:bg-white/10 rounded-full border border-white/10 transition-all active:scale-90'
                    : 'w-10 h-10 flex items-center justify-center bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 transition-all active:scale-90'}
            >
                {isOpen ? <X size={18} className="text-white/70" /> : <Menu size={18} className="text-white/70" />}
            </button>

            {isOpen && (
                <div className={`${panelPosition === 'top' ? 'absolute bottom-16 right-0' : 'absolute top-16 right-4'} bg-slate-900/90 backdrop-blur-2xl rounded-4xl border border-white/10 overflow-hidden shadow-2xl z-[80] animate-fade-up w-64`}>
                    <div className="p-4 space-y-1 border-b border-white/5">
                        <p className="text-xs font-bold text-white/40 uppercase tracking-widest">Cuenta</p>
                        <p className="text-sm font-semibold text-white truncate">{userEmail}</p>
                    </div>

                    <div className="p-4">
                        <button
                            onClick={() => {
                                onOpenChange(false);
                                onLogout();
                                localStorage.clear()
                            }}
                            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 rounded-lg text-rose-300 font-semibold text-sm transition-all"
                        >
                            <LogOut size={16} />
                            Cerrar Sesión
                        </button>
                    </div>
                </div>
            )}
        </>
    );
};
