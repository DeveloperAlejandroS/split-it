import { LayoutGrid, MoonStar, Plus, Settings2, SunMedium, UserCircle2, X } from 'lucide-react';

const drawerItemClass = 'w-full flex items-center gap-4 rounded-3xl px-4 py-4 text-left transition-all duration-200';

export const SideDrawer = ({
    isOpen,
    onOpenChange,
    theme,
    onToggleTheme,
    onLogout,
    onOpenExpenses,
    onOpenFriends,
    onCreateExpense,
    userEmail
}) => {
    if (!isOpen) return null;

    const isLight = theme === 'light';

    return (
        <div className="fixed inset-0 z-120">
            <button
                type="button"
                aria-label="Cerrar menú"
                onClick={() => onOpenChange(false)}
                className="absolute inset-0 bg-slate-950/55 backdrop-blur-3xl"
            />

            <aside className="absolute right-0 top-0 h-full w-[min(100vw,420px)] glass-shell-strong border-l-0 rounded-l-[2.5rem] p-5 sm:p-6 flex flex-col gap-5 animate-fade-up" style={{ background: 'var(--surface-strong)' }}>
                <div className="flex items-start justify-between gap-4">
                    <div>
                        <p className="text-[10px] font-bold uppercase tracking-[0.28em] text-secondary">Perfil</p>
                        <h3 className="mt-2 text-2xl font-extrabold tracking-tight text-primary">Split.it</h3>
                        <p className="mt-2 text-sm text-secondary break-all">{userEmail}</p>
                    </div>

                    <button
                        type="button"
                        onClick={() => onOpenChange(false)}
                        className="h-10 w-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center text-primary hover:bg-white/10 transition-all"
                    >
                        <X size={18} />
                    </button>
                </div>

                <div className="space-y-3">
                    <button type="button" onClick={onOpenExpenses} className={drawerItemClass}>
                        <span className="h-12 w-12 rounded-2xl flex items-center justify-center" style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>
                            <LayoutGrid size={20} />
                        </span>
                        <span className="flex-1">
                            <span className="block text-base font-semibold text-primary">Gastos</span>
                            <span className="block text-xs text-secondary">Volver al activity feed</span>
                        </span>
                    </button>

                    <button type="button" onClick={onOpenFriends} className={drawerItemClass}>
                        <span className="h-12 w-12 rounded-2xl flex items-center justify-center" style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>
                            <UserCircle2 size={20} />
                        </span>
                        <span className="flex-1">
                            <span className="block text-base font-semibold text-primary">Amigos</span>
                            <span className="block text-xs text-secondary">Solicitudes y contactos</span>
                        </span>
                    </button>

                    <button type="button" onClick={onCreateExpense} className={drawerItemClass}>
                        <span className="h-12 w-12 rounded-2xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-strong))', color: 'white' }}>
                            <Plus size={20} />
                        </span>
                        <span className="flex-1">
                            <span className="block text-base font-semibold text-primary">Nuevo gasto</span>
                            <span className="block text-xs text-secondary">Crear una división rápida</span>
                        </span>
                    </button>

                    <button type="button" onClick={onToggleTheme} className={drawerItemClass}>
                        <span className="h-12 w-12 rounded-2xl flex items-center justify-center" style={{ background: 'var(--surface-soft)', color: 'var(--text-primary)' }}>
                            {isLight ? <MoonStar size={20} /> : <SunMedium size={20} />}
                        </span>
                        <span className="flex-1">
                            <span className="block text-base font-semibold text-primary">Tema</span>
                            <span className="block text-xs text-secondary">Cambiar tema</span>
                        </span>

                        <span className="theme-switch" data-active={isLight} aria-hidden="true">
                            <span className="theme-switch-thumb" />
                        </span>
                    </button>
                </div>

                <div className="mt-auto space-y-3">
                    <div className="rounded-3xl p-4 border border-white/10 bg-white/5">
                        <p className="text-[10px] font-bold uppercase tracking-[0.28em] text-secondary mb-2">Acciones rápidas</p>
                        <div className="flex items-center gap-3 text-sm text-secondary">
                            <Settings2 size={16} />
                            <span>Diseño glass, navegación compacta y temas.</span>
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={() => {
                            onOpenChange(false);
                            onLogout();
                            localStorage.clear();
                        }}
                        className="w-full rounded-3xl px-4 py-4 text-sm font-semibold transition-all border border-rose-500/20 bg-rose-500/10 text-rose-300 hover:bg-rose-500/15"
                    >
                        Cerrar sesión
                    </button>
                </div>
            </aside>
        </div>
    );
};